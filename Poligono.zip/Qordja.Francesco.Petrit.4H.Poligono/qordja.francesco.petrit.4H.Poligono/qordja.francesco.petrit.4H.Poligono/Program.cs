﻿using System;

namespace qordja.francesco.petrit._4H.Poligono
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserire il numero di lati");
            string strnumlati = Console.ReadLine();
            Console.WriteLine("Inserire la lunghezza del lati");
            string strlunghezza = Console.ReadLine();

            Poligono figura = new Poligono(Convert.ToInt32(strnumlati), Convert.ToDouble(strlunghezza));
            figura.Perimetro(figura.n, figura.lato);
            figura.Apotema(figura.n, figura.lato);
            figura.Area(figura.n, figura.lato);

            Console.WriteLine($"Perimetro del poligono= {figura.perimetro}");
            Console.WriteLine($"Apotema del poligono ={figura.apotema}");
            Console.WriteLine($"Area del poligono ={figura.area}");
        }
        class Poligono
        {
            public double lato;
            public int n;
            public double nf;
            public double apotema;
            public double area;
            public double perimetro;

            public Poligono()
            {

            }

            public Poligono(int numlati ,double lunghezza )
            {
                lato = numlati;
                n = lunghezza;
            }

            public void Perimetro (int n, double lato)
            {
                perimetro = n * lato;
            }

            public void Apotema (int n,double lato)
            {
                nf = 1 / (2 * Math.Tan(Math.PI / n));
                apotema = nf * lato;
            }

            public void Area(double apotema,double perimetro)
            {
                area = (perimetro * apotema) / 2;
            }

        }
    }
}
